import logo from './logo.svg';
import './App.css';
import { useUsersQuery, usePostsMutation } from './users/usersApi';
import { useState } from 'react';

function App() {
  let formSubmitError;
  const [page, setPage] = useState(1)
  const {data,error,isLoading,isFetching,isSuccess} = useUsersQuery(page);
  console.log("_________________data is here",data,error);
  const [addPosts,response]= usePostsMutation();

  const [postForm,setPostForm]=useState('submit');

  const onSubmit = (e) => {
    try {
      e.preventDefault();
      const {title,body}= e.target.elements;

      let formData = {
        title: title.value,
        body: body.value,
      }

      addPosts(formData).unwrap().then(() => {}).then((error) => {
        console.log("__________________________________________________________",error)
      })
    } catch (error) {
      throw error;
    }
  }




  return (
    <div className="App">
      {isLoading && <h2>Loading...</h2>}
  {isFetching && <h2>Fetching...</h2>}
  {error && <h2>Error...</h2>}

  {
    isSuccess && (
      <>
      {
        data && data?.map((users) => (
          <>
          <p >{users.title}</p>
          <p >{users.body}</p>
          </>
        ))
      }
       <button onClick={() => setPage(page - 1)} isLoading={isFetching}>
Previous
      </button>
      <button onClick={() => setPage(page + 1)} isLoading={isFetching}>
        Next
      </button>

      </>
    )
  }

{formSubmitError}
      <div className="d-flex justify-content-center mb-4">
        <div className="col-md-4 offset-md-*">
          <form onSubmit={onSubmit}>
            <div className="mb-3">
              <label className="form-label">
                <strong>Enter Title</strong>
              </label>
              <input type="text" className="form-control" id="title" />
            </div>
            <div className="mb-3">
              <label className="form-label">
                <strong>Enter content</strong>
              </label>
              <textarea className="form-control" id="body" rows="3"></textarea>
            </div>
            <div className="d-grid">
              <button className="btn btn-danger" type="submit">
                {postForm}
              </button>
            </div>
          </form>
        </div>
      </div>

    </div>
  );
}

export default App;
