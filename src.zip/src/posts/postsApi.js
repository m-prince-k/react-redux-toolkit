import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query";
 
export const postsApi= createApi({
    reducerPath:'postapi',
    baseQuery:fetchBaseQuery({baseUrl:'https://jsonplaceholder.typicode.com/'}),
    endpoints:(builder) => ({
        posts:builder.mutation({
            query:(task) => ({
                url:'/posts',
                method:'POST',
                body:task
            }),
        async onQueryStarted(arg, { queryFulfilled, dispatch }){
            try {
                const response = await queryFulfilled;
                console.log("____________________________________arg is here",response);
                const patchResult = dispatch(postsApi.util.updateQueryData("users",undefined,(draft) => {
                    draft.push(response.data);
                    console.log(JSON.stringify(draft))
                    return draft;
                }))
            } catch (error) {
                console.log("_______________________________________________error is here",error);
            }
        }
        })
    })
});


export const { usePostsQuery }=postsApi;