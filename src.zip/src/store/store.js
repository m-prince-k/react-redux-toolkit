import { configureStore } from "@reduxjs/toolkit";
import { usersApi } from "../users/usersApi";
import { postsApi } from "../posts/postsApi";


export const store = configureStore({
    reducer:{
        [usersApi.reducerPath]:usersApi.reducer,
    },
    middleware:(getDefaultMiddleware) => getDefaultMiddleware().concat([usersApi.middleware])
})