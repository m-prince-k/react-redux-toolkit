import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const usersApi= createApi({
    reducerPath:'api',
    baseQuery:fetchBaseQuery({
        baseUrl:'https://jsonplaceholder.typicode.com/'}),
    endpoints:(builder) => ({
        users:builder.query({
            query:(page=1) => ({
                url:`/posts?page=${page}`,
                method:'GET',
                headers:{"Content-Type":"application/json"}
            }),
        }),
        posts:builder.mutation({
            query:(task) => ({
                url:'/posts',
                method:'POST',
                body:task,
                headers:{"Content-Type":"application/json"}
            }),
        async onQueryStarted(arg, { queryFulfilled, dispatch }){
            try {
                const response = await queryFulfilled;
                console.log("____________________________________arg is here",queryFulfilled);
                 dispatch(usersApi.util.updateQueryData("/posts",undefined,(draft) => {
                    console.log("_____________________inner draft is here",draft)

                    draft.push(response.data);
                    console.log("____________________________________nested draft is here",JSON.stringify(draft))
                    return draft;
                }))
            } catch (error) {
                
            }
        }
        })
    })
});

export const { useUsersQuery, usePostsMutation }=usersApi;