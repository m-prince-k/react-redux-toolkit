export const endpoint={
    users:'users'
}